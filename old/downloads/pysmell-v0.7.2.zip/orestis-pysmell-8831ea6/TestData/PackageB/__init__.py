class SneakyClass:
    pass
    
def SneakyFunction():
    pass
    
SneakyConstant = 42

